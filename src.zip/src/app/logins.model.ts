export class Logins {
    Username;
    Password;
}
