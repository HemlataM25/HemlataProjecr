import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
submit() {
throw new Error('Method not implemented.');
}
form: FormGroup;

  constructor() { }

  ngOnInit(): void {
  }

}
