export class Plan {
    PId;
    Pname;
    Amount;
    Start;
    End;
MrefID: any;
}
