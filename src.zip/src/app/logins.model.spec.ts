import { Logins } from './logins.model';

describe('Logins', () => {
  it('should create an instance', () => {
    expect(new Logins()).toBeTruthy();
  });
});
